from pathlib import Path
import json
import subprocess
import sys
import joblib
import pandas as pd
from flask import Flask, render_template, request

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "saved_model" / "churn_model.joblib"
METRICS_PATH = BASE_DIR / "saved_model" / "metrics.json"

app = Flask(__name__)

def ensure_model():
    if not MODEL_PATH.exists():
        result = subprocess.run(
            [sys.executable, str(BASE_DIR / "train_model.py")],
            cwd=str(BASE_DIR), capture_output=True, text=True
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr or result.stdout or "Model training failed.")
    return joblib.load(MODEL_PATH)

def get_metrics():
    if METRICS_PATH.exists():
        try:
            return json.loads(METRICS_PATH.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return {}
    return {}

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None
    metrics = get_metrics()
    if request.method == "POST":
        try:
            customer = {
                "gender": request.form.get("gender", "Female"),
                "SeniorCitizen": int(request.form.get("SeniorCitizen", "0")),
                "Partner": request.form.get("Partner", "Yes"),
                "Dependents": request.form.get("Dependents", "No"),
                "tenure": int(request.form.get("tenure", "12")),
                "PhoneService": request.form.get("PhoneService", "Yes"),
                "InternetService": request.form.get("InternetService", "Fiber optic"),
                "Contract": request.form.get("Contract", "Month-to-month"),
                "PaperlessBilling": request.form.get("PaperlessBilling", "Yes"),
                "PaymentMethod": request.form.get("PaymentMethod", "Electronic check"),
                "MonthlyCharges": float(request.form.get("MonthlyCharges", "70")),
                "TotalCharges": float(request.form.get("TotalCharges", "840")),
                "TechSupport": request.form.get("TechSupport", "No"),
                "OnlineSecurity": request.form.get("OnlineSecurity", "No")
            }
            if not 0 <= customer["tenure"] <= 72:
                raise ValueError("Tenure must be between 0 and 72 months.")
            if customer["MonthlyCharges"] < 0 or customer["TotalCharges"] < 0:
                raise ValueError("Charges cannot be negative.")
            model = ensure_model()
            input_df = pd.DataFrame([customer])
            probability = float(model.predict_proba(input_df)[0][1])
            prediction = int(probability >= 0.5)
            result = {
                "label": "Likely to Churn" if prediction else "Likely to Stay",
                "probability": round(probability * 100, 1),
                "class": "danger" if prediction else "success",
                "note": ("This model estimate is a decision-support signal, not a guarantee."
                         " Consider reviewing the customer's situation before taking action.")
            }
            metrics = get_metrics()
        except (ValueError, TypeError, RuntimeError, FileNotFoundError) as exc:
            error = str(exc)
    return render_template("index.html", result=result, error=error, metrics=metrics)

if __name__ == "__main__":
    app.run(debug=True)
