Run `python train_model.py` to generate churn_model.joblib and metrics.json. These generated artifacts are intentionally not included.
