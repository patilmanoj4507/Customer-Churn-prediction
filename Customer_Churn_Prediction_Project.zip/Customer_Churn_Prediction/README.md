# Customer Churn Prediction Using Machine Learning

A beginner-friendly Flask web application that estimates whether a subscription customer may churn. It uses a scikit-learn pipeline with preprocessing and a Random Forest classifier.

## Features
- Customer details form with subscription, usage and billing features
- Random Forest binary classification
- Churn probability estimate
- Accuracy, precision, recall, F1 and ROC-AUC metrics after training
- Local CSV dataset included for a reproducible demo

## Project structure
```text
Customer_Churn_Prediction/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── data/
│   └── customer_churn.csv
├── saved_model/
│   └── (generated model and metrics)
└── templates/
    └── index.html
```

## Run on Windows
1. Install Python 3.10 or newer.
2. Open Command Prompt in this folder.
3. Create and activate a virtual environment (optional but recommended):
   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   ```
4. Install dependencies:
   ```bat
   pip install -r requirements.txt
   ```
5. Train the model:
   ```bat
   python train_model.py
   ```
6. Start the web application:
   ```bat
   python app.py
   ```
7. Open `http://127.0.0.1:5000` in your browser.

The app will also attempt to train the model automatically on the first prediction if no saved model exists.

## Dataset note
`data/customer_churn.csv` is a **synthetic demonstration dataset generated for this project**, not real customer information and not the official IBM Telco dataset. Metrics describe performance on a held-out split of this synthetic dataset only. They should not be treated as evidence of real-world business performance. For a serious model, replace this file with a properly licensed real dataset and evaluate on representative data.

## Model
The training script uses a `ColumnTransformer` to one-hot encode categorical columns and impute/scale numeric columns, then trains a `RandomForestClassifier`. The complete preprocessing-plus-model pipeline is saved as `saved_model/churn_model.joblib`.

## Disclaimer
This project is educational. Predictions are estimates and should not be used as the sole basis for decisions about individual customers.
